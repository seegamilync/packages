from ismember.ismember import ismember

__author__ = 'Erdogan Tasksen'
__email__ = 'erdogant@gmail.com'
__version__ = '0.1.2'

# module level doc-string
__doc__ = """
Python package ismember returns array elements that are members of set array.
=====================================================================

**ismember** 
See README.md file for more information.

"""
