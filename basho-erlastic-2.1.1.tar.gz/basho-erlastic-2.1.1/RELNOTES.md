# Basho Erlastic Release Notes

## 2.1.0

Includes changes for Python 3 and 2 compatibility.

Incorporate the following PRs:

* [Compatibility with Python >= 2.6](https://github.com/samuel/python-erlastic/pull/5)
* [Change codec so it does not crashed on func](https://github.com/samuel/python-erlastic/pull/4)
