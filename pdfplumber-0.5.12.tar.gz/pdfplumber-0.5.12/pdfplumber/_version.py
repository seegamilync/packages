version_info = (0, 5, 12)
__version__ = '.'.join(map(str, version_info))
